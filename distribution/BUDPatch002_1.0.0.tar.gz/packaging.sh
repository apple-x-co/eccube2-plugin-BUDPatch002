
plugin_name=BUDPatch002
plugin_version=1.0.0

tar cvfz ../distribution/${plugin_name}_${plugin_version}.tar.gz *
